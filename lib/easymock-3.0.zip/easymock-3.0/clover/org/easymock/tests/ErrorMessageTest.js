var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":60,"id":5373,"methods":[{"el":35,"sc":5,"sl":29},{"el":43,"sc":5,"sl":37},{"el":51,"sc":5,"sl":45},{"el":59,"sc":5,"sl":53}],"name":"ErrorMessageTest","sl":27}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_1057":{"methods":[{"sl":53}],"name":"testAppendTo_matchingMultiple","pass":true,"statements":[{"sl":55},{"sl":56},{"sl":57},{"sl":58}]},"test_117":{"methods":[{"sl":29}],"name":"testGetters","pass":true,"statements":[{"sl":31},{"sl":32},{"sl":33},{"sl":34}]},"test_187":{"methods":[{"sl":53}],"name":"testAppendTo_matchingMultiple","pass":true,"statements":[{"sl":55},{"sl":56},{"sl":57},{"sl":58}]},"test_233":{"methods":[{"sl":37}],"name":"testAppendTo_matchingOne","pass":true,"statements":[{"sl":39},{"sl":40},{"sl":41},{"sl":42}]},"test_238":{"methods":[{"sl":29}],"name":"testGetters","pass":true,"statements":[{"sl":31},{"sl":32},{"sl":33},{"sl":34}]},"test_373":{"methods":[{"sl":45}],"name":"testAppendTo_matchingNone","pass":true,"statements":[{"sl":47},{"sl":48},{"sl":49},{"sl":50}]},"test_673":{"methods":[{"sl":37}],"name":"testAppendTo_matchingOne","pass":true,"statements":[{"sl":39},{"sl":40},{"sl":41},{"sl":42}]},"test_806":{"methods":[{"sl":45}],"name":"testAppendTo_matchingNone","pass":true,"statements":[{"sl":47},{"sl":48},{"sl":49},{"sl":50}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [238, 117], [], [238, 117], [238, 117], [238, 117], [238, 117], [], [], [673, 233], [], [673, 233], [673, 233], [673, 233], [673, 233], [], [], [806, 373], [], [806, 373], [806, 373], [806, 373], [806, 373], [], [], [187, 1057], [], [187, 1057], [187, 1057], [187, 1057], [187, 1057], [], []]
