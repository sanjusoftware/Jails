var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":57,"id":5473,"methods":[{"el":41,"sc":5,"sl":37},{"el":56,"sc":5,"sl":43}],"name":"MatchableArgumentsTest","sl":31}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_370":{"methods":[{"sl":43}],"name":"testEquals","pass":true,"statements":[{"sl":45},{"sl":47},{"sl":49},{"sl":51},{"sl":54},{"sl":55}]},"test_986":{"methods":[{"sl":43}],"name":"testEquals","pass":true,"statements":[{"sl":45},{"sl":47},{"sl":49},{"sl":51},{"sl":54},{"sl":55}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [986, 370], [], [986, 370], [], [986, 370], [], [986, 370], [], [986, 370], [], [], [986, 370], [986, 370], [], []]
