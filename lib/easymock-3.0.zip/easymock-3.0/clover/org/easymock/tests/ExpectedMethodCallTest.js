var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":51,"id":5393,"methods":[{"el":40,"sc":5,"sl":35},{"el":50,"sc":5,"sl":42}],"name":"ExpectedMethodCallTest","sl":31}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_172":{"methods":[{"sl":42}],"name":"testHashCode","pass":true,"statements":[{"sl":44},{"sl":45},{"sl":48}]},"test_228":{"methods":[{"sl":42}],"name":"testHashCode","pass":true,"statements":[{"sl":44},{"sl":45},{"sl":48}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [228, 172], [], [228, 172], [228, 172], [], [], [228, 172], [], [], []]
