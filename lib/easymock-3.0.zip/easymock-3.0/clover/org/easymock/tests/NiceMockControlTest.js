var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":61,"id":5606,"methods":[{"el":36,"sc":5,"sl":32},{"el":42,"sc":5,"sl":38},{"el":48,"sc":5,"sl":44},{"el":54,"sc":5,"sl":50},{"el":60,"sc":5,"sl":56}],"name":"NiceMockControlTest","sl":28}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_1067":{"methods":[{"sl":44}],"name":"defaultReturnValueFloat","pass":true,"statements":[{"sl":46},{"sl":47}]},"test_139":{"methods":[{"sl":56}],"name":"defaultReturnValueObject","pass":true,"statements":[{"sl":58},{"sl":59}]},"test_158":{"methods":[{"sl":50}],"name":"defaultReturnValueDouble","pass":true,"statements":[{"sl":52},{"sl":53}]},"test_338":{"methods":[{"sl":50}],"name":"defaultReturnValueDouble","pass":true,"statements":[{"sl":52},{"sl":53}]},"test_43":{"methods":[{"sl":38}],"name":"defaultReturnValueBoolean","pass":true,"statements":[{"sl":40},{"sl":41}]},"test_535":{"methods":[{"sl":44}],"name":"defaultReturnValueFloat","pass":true,"statements":[{"sl":46},{"sl":47}]},"test_58":{"methods":[{"sl":38}],"name":"defaultReturnValueBoolean","pass":true,"statements":[{"sl":40},{"sl":41}]},"test_669":{"methods":[{"sl":56}],"name":"defaultReturnValueObject","pass":true,"statements":[{"sl":58},{"sl":59}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [43, 58], [], [43, 58], [43, 58], [], [], [1067, 535], [], [1067, 535], [1067, 535], [], [], [338, 158], [], [338, 158], [338, 158], [], [], [139, 669], [], [139, 669], [139, 669], [], []]
