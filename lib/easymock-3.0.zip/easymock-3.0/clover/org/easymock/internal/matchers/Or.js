var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":57,"id":2797,"methods":[{"el":36,"sc":5,"sl":34},{"el":45,"sc":5,"sl":38},{"el":56,"sc":5,"sl":47}],"name":"Or","sl":28}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_1038":{"methods":[{"sl":34},{"sl":47}],"name":"orToString","pass":true,"statements":[{"sl":35},{"sl":48},{"sl":49},{"sl":50},{"sl":51},{"sl":52},{"sl":55}]},"test_1078":{"methods":[{"sl":34},{"sl":47}],"name":"orToString","pass":true,"statements":[{"sl":35},{"sl":48},{"sl":49},{"sl":50},{"sl":51},{"sl":52},{"sl":55}]},"test_254":{"methods":[{"sl":34},{"sl":38}],"name":"testOr","pass":true,"statements":[{"sl":35},{"sl":39},{"sl":40},{"sl":41},{"sl":44}]},"test_77":{"methods":[{"sl":34},{"sl":38}],"name":"orOverloaded","pass":true,"statements":[{"sl":35},{"sl":39},{"sl":40},{"sl":41}]},"test_84":{"methods":[{"sl":34},{"sl":38}],"name":"testOr","pass":true,"statements":[{"sl":35},{"sl":39},{"sl":40},{"sl":41},{"sl":44}]},"test_923":{"methods":[{"sl":34},{"sl":38}],"name":"orOverloaded","pass":true,"statements":[{"sl":35},{"sl":39},{"sl":40},{"sl":41}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [1078, 254, 77, 1038, 923, 84], [1078, 254, 77, 1038, 923, 84], [], [], [254, 77, 923, 84], [254, 77, 923, 84], [254, 77, 923, 84], [254, 77, 923, 84], [], [], [254, 84], [], [], [1078, 1038], [1078, 1038], [1078, 1038], [1078, 1038], [1078, 1038], [1078, 1038], [], [], [1078, 1038], [], []]
